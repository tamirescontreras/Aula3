# 3 - Econometria Avançada - Aula 3
Slides e código para aula 3 de Econometria Avançada
